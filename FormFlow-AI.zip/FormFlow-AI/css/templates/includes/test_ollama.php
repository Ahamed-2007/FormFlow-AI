<?php

require_once "includes/ollama.php";

$prompt = "You are FormFlow AI. Reply only with this sentence: PHP successfully connected to Ollama.";

$result = askOllama($prompt);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Ollama Test</title>
</head>
<body>

    <h1>FormFlow AI - Ollama Test</h1>

    <?php if ($result["success"]): ?>
        <p style="color: green;">
            <?php echo htmlspecialchars($result["message"]); ?>
        </p>
    <?php else: ?>
        <p style="color: red;">
            <?php echo htmlspecialchars($result["message"]); ?>
        </p>
    <?php endif; ?>

</body>
</html>