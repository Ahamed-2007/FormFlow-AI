<?php

function askOllama($prompt)
{
    $data = json_encode([
        "model" => OLLAMA_MODEL,
        "prompt" => $prompt,
        "stream" => false
    ]);

    $options = [
        "http" => [
            "method" => "POST",
            "header" => "Content-Type: application/json\r\n",
            "content" => $data,
            "timeout" => 120,
            "ignore_errors" => true
        ]
    ];

    $context = stream_context_create($options);

    $result = file_get_contents(
        OLLAMA_URL,
        false,
        $context
    );

    if ($result === false) {
        return "ERROR: Cannot connect to Ollama.";
    }

    $response = json_decode($result, true);

    if (isset($response["error"])) {
        return "OLLAMA ERROR: " . $response["error"];
    }

    return $response["response"] ?? "No response received.";
}

?>