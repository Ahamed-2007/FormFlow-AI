
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


require_once "config.php";
require_once "includes/ollama.php";
echo "PHP CONNECTION WORKS";
exit;

$formType = $_POST["form_type"] ?? "";
$question = $_POST["question"] ?? "";

if (!$formType || !$question) {
    die("Please select a form and enter your question.");
}

$formDescriptions = [

    "Income Certificate" =>
        "A certificate generally used to prove the income of an individual or family for applications such as scholarships, education benefits and government schemes.",

    "Community Certificate" =>
        "A certificate used to establish a person's community or caste category when required for an application.",

    "Residence Certificate" =>
        "A certificate used to establish a person's residence or address for certain applications and services.",

    "Scholarship Application" =>
        "An application used by students to apply for an educational scholarship. Requirements vary depending on the scholarship.",

    "Bank KYC Form" =>
        "A bank form used to provide customer identification and KYC information. Requirements vary by bank and service."

];

$description = $formDescriptions[$formType] ?? "A government or banking application form.";

$prompt = <<<PROMPT

You are FormFlow AI, an Application Journey Navigator.

The user selected this form:

FORM:
$formType

DESCRIPTION:
$description

USER QUESTION:
$question

Give a practical and easy-to-understand answer.

Use these sections where relevant:

WHAT IS THIS?
WHO NEEDS IT?
DOCUMENTS REQUIRED NOW
CONDITIONAL DOCUMENTS
FUTURE / FOLLOW-UP REQUIREMENTS
IMPORTANT FIELDS
APPLICATION PROCESS
WHAT HAPPENS AFTER SUBMISSION?
COMMON MISTAKES
IMPORTANT NOTE

Rules:

- Give clear and simple explanations.
- Do not invent official rules.
- Do not invent exact fees or deadlines.
- If requirements depend on a government department, bank, scholarship provider or state, clearly say so.
- Separate documents required now from conditional documents.
- Explain what may happen after submission.
- Do not claim to be an official government or bank service.
- If you are unsure about an official requirement, say that it must be verified with the relevant authority.

PROMPT;

$answer = askOllama($prompt);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>FormFlow AI - Result</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<nav class="navbar navbar-dark bg-dark">

    <div class="container">

        <a class="navbar-brand fw-bold" href="index.php">
            FormFlow AI
        </a>

        <span class="text-light">
            AI Analysis
        </span>

    </div>

</nav>


<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-10">

            <div class="mb-4">

                <span class="badge bg-primary">
                    Form Analyzed
                </span>

                <h1 class="mt-3">
                    <?php echo htmlspecialchars($formType); ?>
                </h1>

                <p class="text-secondary">
                    Your application journey guidance
                </p>

            </div>


            <div class="card main-card">

                <div class="card-body p-4 p-md-5">

                    <h4 class="mb-4">
                        ✨ FormFlow AI Guidance
                    </h4>

                    <div
                        style="
                        white-space: pre-wrap;
                        line-height: 1.8;
                        font-size: 16px;
                        "
                    >
                        <?php echo htmlspecialchars($answer); ?>
                    </div>

                </div>

            </div>


            <div class="text-center mt-4">

                <a
                    href="index.php"
                    class="btn btn-outline-primary"
                >
                    ← Analyze Another Form
                </a>

            </div>

        </div>

    </div>

</div>

</body>

</html>