<?php

define("OLLAMA_URL", "http://localhost:11434/api/generate");
define("OLLAMA_MODEL", "llama3.2:3b");

?>