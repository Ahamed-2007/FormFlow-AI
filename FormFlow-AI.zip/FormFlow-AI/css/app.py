from flask import Flask, render_template, request
import requests

app = Flask(__name__)

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.2:3b"


@app.route("/", methods=["GET", "POST"])
def home():
    answer = ""

    if request.method == "POST":
        user_question = request.form.get("question", "")

        prompt = f"""
You are FormFlow AI, an application and form guidance assistant.

Answer the user's question clearly and simply.

User question:
{user_question}
"""

        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL,
                "prompt": prompt,
                "stream": False
            }
        )

        if response.status_code == 200:
            answer = response.json()["response"]
        else:
            answer = "Sorry, I could not connect to Ollama."

    return render_template("index.html", answer=answer)


if __name__ == "__main__":
    app.run(debug=True)