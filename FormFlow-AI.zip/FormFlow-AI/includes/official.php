<?php
declare(strict_types=1);

function formFlowOfficialSources(): array
{
    return [
        'Income Certificate' => [
            'authority' => 'Tamil Nadu e-Sevai',
            'application_url' => 'https://www.tnesevai.tn.gov.in/',
            'information_url' => 'https://www.tnesevai.tn.gov.in/Pages/ServiceList.aspx',
            'source_label' => 'Official Tamil Nadu Government e-Sevai Portal',
            'verified' => true,
            'last_verified_date' => '2026-09-04',
            'scope_note' => 'For applicants using Tamil Nadu services. Requirements and service availability vary by authority and location.',
        ],
        'Community Certificate' => [
            'authority' => 'Tamil Nadu e-Sevai',
            'application_url' => 'https://www.tnesevai.tn.gov.in/',
            'information_url' => 'https://www.tnesevai.tn.gov.in/Pages/ServiceList.aspx',
            'source_label' => 'Official Tamil Nadu Government e-Sevai Portal',
            'verified' => true,
            'last_verified_date' => '2026-09-04',
            'scope_note' => 'For applicants using Tamil Nadu services. Requirements and service availability vary by authority and location.',
        ],
        'Residence Certificate' => [
            'authority' => 'Tamil Nadu e-Sevai',
            'application_url' => 'https://www.tnesevai.tn.gov.in/',
            'information_url' => 'https://www.tnesevai.tn.gov.in/Pages/ServiceList.aspx',
            'source_label' => 'Official Tamil Nadu Government e-Sevai Portal',
            'verified' => true,
            'last_verified_date' => '2026-09-04',
            'scope_note' => 'For applicants using Tamil Nadu services. Requirements and service availability vary by authority and location.',
        ],
        'Scholarship Application' => [
            'authority' => 'Scholarship provider or education authority',
            'application_url' => null,
            'information_url' => null,
            'source_label' => null,
            'verified' => false,
            'last_verified_date' => null,
            'scope_note' => 'The correct portal depends on the scholarship provider, institution, and current scheme instructions.',
        ],
        'Bank KYC' => [
            'authority' => 'Relevant bank',
            'application_url' => null,
            'information_url' => null,
            'source_label' => null,
            'verified' => false,
            'last_verified_date' => null,
            'scope_note' => 'Use the bank’s official website, app, branch, or communication channel after confirming the bank name.',
        ],
        "Learner's Licence" => [
            'authority' => 'Parivahan Sewa / Sarathi',
            'application_url' => 'https://sarathi.parivahan.gov.in/sarathiservice/stateSelection.do',
            'information_url' => 'https://parivahan.gov.in/',
            'source_label' => 'Official Government of India Parivahan / Sarathi Portal',
            'verified' => true,
            'last_verified_date' => '2026-09-04',
            'scope_note' => 'Select the relevant state or jurisdiction in the official portal. Rules and stages vary by jurisdiction.',
        ],
        'Driving Licence' => [
            'authority' => 'Parivahan Sewa / Sarathi',
            'application_url' => 'https://sarathi.parivahan.gov.in/sarathiservice/stateSelection.do',
            'information_url' => 'https://parivahan.gov.in/',
            'source_label' => 'Official Government of India Parivahan / Sarathi Portal',
            'verified' => true,
            'last_verified_date' => '2026-09-04',
            'scope_note' => 'Select the relevant state or jurisdiction in the official portal. Rules and stages vary by jurisdiction.',
        ],
    ];
}
