<?php
declare(strict_types=1);

if (!function_exists('e')) {
    function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}

function formFlowDocumentLabels(string $language): array
{
    $labels = [
        'en' => ['title'=>'Download Your Guide','description'=>'Save your personalized application procedure and checklist for offline use.','pdf'=>'Download PDF','word'=>'Download Word','what_do'=>'What to do','what_not'=>'What not to do','checklist'=>'Application preparation checklist','available'=>'Available','prepare'=>'Need to prepare','verify'=>'Conditional / verify','stage'=>'Current journey stage','important'=>'Important note','disclaimer'=>'FormFlow AI provides guidance for preparation and does not replace instructions from the official authority.','official_unavailable'=>'Official application link is not currently available in the trusted configuration.','next'=>'Your next action'],
        'ta' => ['title'=>'உங்கள் வழிகாட்டியைப் பதிவிறக்கவும்','description'=>'உங்கள் தனிப்பயன் விண்ணப்ப நடைமுறை மற்றும் பட்டியலை இணையமின்றி பயன்படுத்த சேமிக்கவும்.','pdf'=>'PDF பதிவிறக்கம்','word'=>'Word பதிவிறக்கம்','what_do'=>'செய்ய வேண்டியது','what_not'=>'செய்யக் கூடாதது','checklist'=>'விண்ணப்பத் தயார்நிலைப் பட்டியல்','available'=>'கிடைக்கிறது','prepare'=>'தயாரிக்க வேண்டும்','verify'=>'நிபந்தனை / சரிபார்க்கவும்','stage'=>'தற்போதைய பயணக் கட்டம்','important'=>'முக்கிய குறிப்பு','disclaimer'=>'FormFlow AI தயாரிப்புக்கான வழிகாட்டுதலை வழங்குகிறது; இது அதிகாரப்பூர்வ அதிகாரத்தின் அறிவுறுத்தல்களை மாற்றாது.','official_unavailable'=>'நம்பகமான அமைப்பில் அதிகாரப்பூர்வ விண்ணப்ப இணைப்பு தற்போது கிடைக்கவில்லை.','next'=>'உங்கள் அடுத்த செயல்'],
        'hi' => ['title'=>'अपना मार्गदर्शक डाउनलोड करें','description'=>'अपनी व्यक्तिगत आवेदन प्रक्रिया और सूची को ऑफलाइन उपयोग के लिए सहेजें।','pdf'=>'PDF डाउनलोड करें','word'=>'Word डाउनलोड करें','what_do'=>'क्या करें','what_not'=>'क्या न करें','checklist'=>'आवेदन तैयारी सूची','available'=>'उपलब्ध','prepare'=>'तैयारी आवश्यक','verify'=>'सशर्त / सत्यापित करें','stage'=>'वर्तमान यात्रा चरण','important'=>'महत्वपूर्ण नोट','disclaimer'=>'FormFlow AI तैयारी के लिए मार्गदर्शन देता है और आधिकारिक प्राधिकरण के निर्देशों का स्थान नहीं लेता।','official_unavailable'=>'विश्वसनीय कॉन्फ़िगरेशन में आधिकारिक आवेदन लिंक अभी उपलब्ध नहीं है।','next'=>'आपका अगला कार्य'],
        'ml' => ['title'=>'നിങ്ങളുടെ മാർഗ്ഗനിർദ്ദേശം ഡൗൺലോഡ് ചെയ്യുക','description'=>'നിങ്ങളുടെ വ്യക്തിഗത അപേക്ഷാ നടപടിക്രമവും പട്ടികയും ഓഫ്‌ലൈനായി ഉപയോഗിക്കാൻ സേവ് ചെയ്യുക.','pdf'=>'PDF ഡൗൺലോഡ് ചെയ്യുക','word'=>'Word ഡൗൺലോഡ് ചെയ്യുക','what_do'=>'ചെയ്യേണ്ടത്','what_not'=>'ചെയ്യരുതാത്തത്','checklist'=>'അപേക്ഷാ തയ്യാറെടുപ്പ് പട്ടിക','available'=>'ലഭ്യമാണ്','prepare'=>'തയ്യാറാക്കണം','verify'=>'നിബന്ധന / പരിശോധിക്കുക','stage'=>'നിലവിലെ യാത്രാ ഘട്ടം','important'=>'പ്രധാന കുറിപ്പ്','disclaimer'=>'FormFlow AI തയ്യാറെടുപ്പിനുള്ള മാർഗ്ഗനിർദ്ദേശം നൽകുന്നു; ഇത് ഔദ്യോഗിക അധികാരിയുടെ നിർദ്ദേശങ്ങൾക്ക് പകരമല്ല.','official_unavailable'=>'വിശ്വസനീയമായ ക്രമീകരണത്തിൽ ഔദ്യോഗിക അപേക്ഷാ ലിങ്ക് നിലവിൽ ലഭ്യമല്ല.','next'=>'നിങ്ങളുടെ അടുത്ത നടപടി'],
    ];
    return $labels[$language] ?? $labels['en'];
}
function formFlowGuideData(string $serviceName, string $language, array $checklist, string $readiness, string $answer, string $nextAction, array $official, array $journey): array
{
    $labels = formFlowDocumentLabels($language);
    $do = [
        'en' => ['Keep your available information ready.','Review details before submitting.','Use the trusted official portal when one is configured.','Keep a submission reference if the authority provides one.'],
        'ta' => ['உங்களிடம் உள்ள தகவல்களைத் தயாராக வைத்திருங்கள்.','சமர்ப்பிப்பதற்கு முன் விவரங்களைச் சரிபார்க்கவும்.','உள்ளமைக்கப்பட்ட நம்பகமான அதிகாரப்பூர்வ தளத்தைப் பயன்படுத்தவும்.','அதிகாரம் வழங்கும் சமர்ப்பிப்பு எண்ணை சேமிக்கவும்.'],
        'hi' => ['उपलब्ध जानकारी तैयार रखें।','जमा करने से पहले विवरण जाँचें।','कॉन्फ़िगर किए गए विश्वसनीय आधिकारिक पोर्टल का उपयोग करें।','प्राधिकरण द्वारा दिया गया संदर्भ सुरक्षित रखें।'],
        'ml' => ['ലഭ്യമായ വിവരങ്ങൾ തയ്യാറാക്കി വയ്ക്കുക.','സമർപ്പിക്കുന്നതിന് മുമ്പ് വിവരങ്ങൾ പരിശോധിക്കുക.','ക്രമീകരിച്ച വിശ്വസനീയമായ ഔദ്യോഗിക പോർട്ടൽ ഉപയോഗിക്കുക.','അധികാരം നൽകുന്ന റഫറൻസ് സൂക്ഷിക്കുക.'],
    ][$language] ?? [];
    $dont = [
        'en' => ['Do not enter incorrect personal information.','Do not submit incomplete information.','Do not share OTPs, passwords, PINs, or login credentials.','Do not rely on unofficial application links.'],
        'ta' => ['தவறான தனிப்பட்ட தகவல்களை உள்ளிட வேண்டாம்.','முழுமையற்ற தகவல்களை சமர்ப்பிக்க வேண்டாம்.','OTP, கடவுச்சொல், PIN அல்லது உள்நுழைவு தகவல்களை பகிர வேண்டாம்.','அதிகாரப்பூர்வமற்ற விண்ணப்ப இணைப்புகளை நம்ப வேண்டாம்.'],
        'hi' => ['गलत व्यक्तिगत जानकारी दर्ज न करें।','अधूरी जानकारी जमा न करें।','OTP, पासवर्ड, PIN या लॉगिन जानकारी साझा न करें।','अनौपचारिक आवेदन लिंक पर भरोसा न करें।'],
        'ml' => ['തെറ്റായ വ്യക്തിഗത വിവരങ്ങൾ നൽകരുത്.','പൂർണ്ണമല്ലാത്ത വിവരങ്ങൾ സമർപ്പിക്കരുത്.','OTP, പാസ്‌വേഡ്, PIN അല്ലെങ്കിൽ ലോഗിൻ വിവരങ്ങൾ പങ്കിടരുത്.','ഔദ്യോഗികമല്ലാത്ത അപേക്ഷാ ലിങ്കുകളിൽ വിശ്വസിക്കരുത്.'],
    ][$language] ?? [];
    $answer = preg_replace('/\b(password|passcode|otp|one[- ]time password|pin|login credential)\b[^.\n]*/iu', '[sensitive information omitted]', $answer) ?? $answer;
    $nextAction = preg_replace('/\b(password|passcode|otp|one[- ]time password|pin|login credential)\b[^.\n]*/iu', '[sensitive information omitted]', $nextAction) ?? $nextAction;
    return compact('serviceName','language','checklist','readiness','answer','nextAction','official','journey','labels','do','dont');
}
function formFlowSafeFilename(string $serviceName, string $extension): string
{
    $name = preg_replace('/[^A-Za-z0-9]+/', '_', $serviceName) ?: 'Application';
    return 'FormFlow_' . trim($name, '_') . '_Guide.' . $extension;
}
function formFlowGuideText(array $guide): string
{
    $lines = ['FormFlow AI', $guide['serviceName'] . ' — Application Guide', '', $guide['labels']['stage'] . ': ' . ($guide['journey'][0] ?? ''), 'Readiness: ' . $guide['readiness'], '', 'ANSWER', strip_tags($guide['answer']), '', strtoupper($guide['labels']['checklist'])];
    foreach ($guide['checklist'] as $item) $lines[] = '[' . strtoupper($item['status']) . '] ' . $item['label'];
    $lines[] = ''; $lines[] = strtoupper($guide['labels']['what_do']); foreach ($guide['do'] as $item) $lines[] = '+ ' . $item;
    $lines[] = ''; $lines[] = strtoupper($guide['labels']['what_not']); foreach ($guide['dont'] as $item) $lines[] = '- ' . $item;
    $lines[] = ''; $lines[] = strtoupper($guide['labels']['next']); $lines[] = $guide['nextAction'];
    $lines[] = ''; $lines[] = strtoupper($guide['labels']['important']); $lines[] = $guide['labels']['disclaimer'];
    if (!empty($guide['official']['verified']) && !empty($guide['official']['application_url'])) { $lines[] = 'Official URL: ' . $guide['official']['application_url']; $lines[] = 'Source: ' . ($guide['official']['source_label'] ?? ''); $lines[] = 'Last verified: ' . ($guide['official']['last_verified_date'] ?? ''); } else $lines[] = $guide['labels']['official_unavailable'];
    return implode("\n", $lines);
}
function outputFormFlowWord(array $guide): never
{
    $text = formFlowGuideText($guide);
    header('Content-Type: application/msword; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . formFlowSafeFilename($guide['serviceName'], 'doc') . '"');
    echo '<html><head><meta charset="UTF-8"><title>FormFlow AI — Application Guide</title></head><body><pre style="font-family:Arial;white-space:pre-wrap">' . htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre></body></html>';
    exit;
}
function outputFormFlowPdf(array $guide): never
{
    $chromePaths = [
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    ];
    $browser = null;
    foreach ($chromePaths as $candidate) {
        if (is_file($candidate)) { $browser = $candidate; break; }
    }
    if ($browser !== null && function_exists('proc_open')) {
        $htmlPath = tempnam(sys_get_temp_dir(), 'formflow-guide-') . '.html';
        $pdfPath = tempnam(sys_get_temp_dir(), 'formflow-guide-') . '.pdf';
        $html = '<!doctype html><html lang="' . e($guide['language']) . '"><head><meta charset="UTF-8"><style>body{font-family:Arial,"Noto Sans",sans-serif;margin:42px;color:#17212b}h1{color:#0e4d40;border-bottom:2px solid #176b58;padding-bottom:10px}h2{color:#176b58;margin-top:26px}li{margin:7px 0}.meta{padding:12px;background:#eef5ef}.note{padding:12px;background:#fff8e8;border-left:4px solid #f4c96b}a{color:#176b58}</style></head><body><h1>FormFlow AI</h1><h2>' . e($guide['serviceName']) . ' — Application Guide</h2><div class="meta"><strong>' . e($guide['labels']['stage']) . ':</strong> ' . e($guide['journey'][0] ?? '') . '<br><strong>Readiness:</strong> ' . e($guide['readiness']) . '</div><h2>Answer</h2><p>' . nl2br(e(strip_tags($guide['answer']))) . '</p><h2>' . e($guide['labels']['checklist']) . '</h2><ul>';
        foreach ($guide['checklist'] as $item) $html .= '<li><strong>[' . e(strtoupper($item['status'])) . ']</strong> ' . e($item['label']) . '</li>';
        $html .= '</ul><h2>' . e($guide['labels']['what_do']) . '</h2><ul>'; foreach ($guide['do'] as $item) $html .= '<li>✓ ' . e($item) . '</li>'; $html .= '</ul><h2>' . e($guide['labels']['what_not']) . '</h2><ul>'; foreach ($guide['dont'] as $item) $html .= '<li>✗ ' . e($item) . '</li>'; $html .= '</ul><h2>' . e($guide['labels']['next']) . '</h2><p>' . e($guide['nextAction']) . '</p><h2>' . e($guide['labels']['important']) . '</h2><div class="note">' . e($guide['labels']['disclaimer']) . '</div>';
        if (!empty($guide['official']['verified']) && !empty($guide['official']['application_url'])) $html .= '<h2>' . e($guide['labels']['official_unavailable']) . '</h2><p><a href="' . e($guide['official']['application_url']) . '">' . e($guide['official']['application_url']) . '</a></p><p>' . e($guide['official']['source_label'] ?? '') . '<br>' . e($guide['official']['last_verified_date'] ?? '') . '</p>';
        else $html .= '<h2>' . e($guide['labels']['official_unavailable']) . '</h2>';
        $html .= '</body></html>';
        file_put_contents($htmlPath, $html);
        $command = '"' . $browser . '" --headless=new --disable-gpu --no-sandbox --no-pdf-header-footer --print-to-pdf="' . $pdfPath . '" "file:///' . str_replace('\\', '/', $htmlPath) . '"';
        $process = proc_open($command, [1 => ['pipe','w'], 2 => ['pipe','w']], $pipes);
        if (is_resource($process)) { foreach ($pipes as $pipe) fclose($pipe); proc_close($process); }
        if (is_file($pdfPath) && filesize($pdfPath) > 100) {
            $pdf = file_get_contents($pdfPath);
            @unlink($htmlPath); @unlink($pdfPath);
            if ($pdf !== false) { while (ob_get_level() > 0) ob_end_clean(); header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="' . formFlowSafeFilename($guide['serviceName'], 'pdf') . '"'); header('Content-Length: ' . strlen($pdf)); header('Content-Transfer-Encoding: binary'); echo $pdf; exit; }
        }
        @unlink($htmlPath); @unlink($pdfPath);
    }
    $text = preg_replace('/[^\x20-\x7E\r\n]/', '?', formFlowGuideText($guide)) ?? '';
    $stream = "BT /F1 10 Tf 45 760 Td 14 TL\n";
    foreach (preg_split('/\R/', $text) ?: [] as $line) { $stream .= '(' . str_replace(['\\','(',')'], ['\\\\','\\(','\\)'], substr($line, 0, 105)) . ") Tj T*\n"; }
    $stream .= 'ET';
    $objects = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>", "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>", "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream"];
    $pdf = "%PDF-1.4\n"; $offsets = [0]; foreach ($objects as $i => $object) { $offsets[] = strlen($pdf); $pdf .= ($i + 1) . " 0 obj\n" . $object . "\nendobj\n"; } $xref = strlen($pdf); $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n"; for ($i = 1; $i <= count($objects); $i++) $pdf .= sprintf('%010d 00000 n \n', $offsets[$i]); $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . formFlowSafeFilename($guide['serviceName'], 'pdf') . '"');
    header('Content-Length: ' . strlen($pdf));
    header('Content-Transfer-Encoding: binary');
    echo $pdf;
    exit;
}
