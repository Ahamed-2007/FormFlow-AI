<?php
declare(strict_types=1);

function readHttpLine($socket): string
{
    $line = fgets($socket);
    if ($line === false) {
        throw new RuntimeException('The local AI model closed the connection unexpectedly.');
    }
    return $line;
}

function readHttpResponse($socket): string
{
    $statusLine = readHttpLine($socket);
    $headers = [];
    while (($line = readHttpLine($socket)) !== "\r\n" && trim($line) !== '') {
        $parts = explode(':', $line, 2);
        if (count($parts) === 2) {
            $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
        }
    }

    $body = '';
    if (isset($headers['content-length'])) {
        $remaining = (int) $headers['content-length'];
        while ($remaining > 0) {
            $chunk = fread($socket, min(8192, $remaining));
            if ($chunk === false || $chunk === '') {
                throw new RuntimeException('The local AI model returned an incomplete response.');
            }
            $body .= $chunk;
            $remaining -= strlen($chunk);
        }
    } elseif (str_contains(strtolower($headers['transfer-encoding'] ?? ''), 'chunked')) {
        while (true) {
            $sizeLine = trim(readHttpLine($socket));
            $chunkSize = hexdec(explode(';', $sizeLine, 2)[0]);
            if ($chunkSize === 0) {
                readHttpLine($socket);
                break;
            }
            $chunk = '';
            while (strlen($chunk) < $chunkSize) {
                $part = fread($socket, $chunkSize - strlen($chunk));
                if ($part === false || $part === '') {
                    throw new RuntimeException('The local AI model returned an incomplete response.');
                }
                $chunk .= $part;
            }
            $body .= $chunk;
            readHttpLine($socket);
        }
    } else {
        $body = stream_get_contents($socket);
    }

    if (preg_match('/\s(\d{3})\s/', $statusLine, $matches) !== 1 || (int) $matches[1] < 200 || (int) $matches[1] >= 300) {
        throw new RuntimeException('The local AI model returned an HTTP error.');
    }

    return $body;
}

function ollamaRequest(string $url, string $method = 'GET', ?string $payload = null, int $timeout = OLLAMA_REQUEST_TIMEOUT): string
{
    $path = parse_url($url, PHP_URL_PATH) ?: '/';
    $socket = @stream_socket_client('tcp://127.0.0.1:11434', $errorCode, $errorMessage, OLLAMA_CONNECT_TIMEOUT);
    if ($socket === false) {
        throw new RuntimeException('Unable to connect to the local AI model. Please make sure Ollama is running.');
    }

    stream_set_timeout($socket, $timeout);
    $body = $payload ?? '';
    $request = $method . ' ' . $path . " HTTP/1.1\r\n"
        . "Host: 127.0.0.1:11434\r\n"
        . "Accept: application/json\r\n"
        . ($payload !== null ? "Content-Type: application/json\r\n" : '')
        . "Content-Length: " . strlen($body) . "\r\n"
        . "Connection: close\r\n\r\n"
        . $body;

    $previousLimit = ini_get('max_execution_time');
    set_time_limit($timeout + 10);
    try {
        if (fwrite($socket, $request) === false) {
            throw new RuntimeException('Unable to send the request to the local AI model.');
        }
        $responseBody = readHttpResponse($socket);
        $metadata = stream_get_meta_data($socket);
    } catch (RuntimeException $error) {
        $metadata = stream_get_meta_data($socket);
        fclose($socket);
        if (($metadata['timed_out'] ?? false) === true) {
            throw new RuntimeException('The local AI model took too long to respond. Please try again.');
        }
        throw $error;
    } finally {
        if (is_resource($socket)) {
            fclose($socket);
        }
        if ($previousLimit !== false && (int) $previousLimit > 0) {
            set_time_limit((int) $previousLimit);
        }
    }

    if (($metadata['timed_out'] ?? false) === true) {
        throw new RuntimeException('The local AI model took too long to respond. Please try again.');
    }
    return $responseBody;
}

function ensureOllamaIsReachable(): void
{
    ollamaRequest(OLLAMA_HOST . '/api/tags', 'GET', null, OLLAMA_CONNECT_TIMEOUT);
}

function generateOllamaResponse(string $prompt, int $maxTokens = 700, int $requestTimeout = OLLAMA_REQUEST_TIMEOUT): string
{
    ensureOllamaIsReachable();
    $payload = json_encode([
        'model' => OLLAMA_MODEL,
        'prompt' => $prompt,
        'stream' => false,
        'options' => [
            'num_predict' => $maxTokens,
        ],
    ], JSON_THROW_ON_ERROR);
    $rawResponse = ollamaRequest(OLLAMA_URL, 'POST', $payload, $requestTimeout);

    try {
        $response = json_decode($rawResponse, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new RuntimeException('The local AI model returned invalid JSON. Please try again.');
    }

    $answer = trim((string) ($response['response'] ?? ''));
    if ($answer === '') {
        throw new RuntimeException('The local AI model returned an empty answer. Please try again.');
    }
    return $answer;
}
